# Manuals Folder

Place your **six manuals** here (docx/pdf):

1. Mission_Manual_(LCARS_OS_Conversion).docx
2. Decision_Matrix_(Detailed).docx
3. Priority_Roadmap_(Detailed).docx
4. Storage_and_Infrastructure_Manual.docx
5. Operations_Logbook.docx
6. LCARS_OS_Visual_Guide.docx

Stardate baseline: **2025.234**.

# Infrastructure

- docker-compose templates (HQ services)
- WireGuard server/client examples
- Backup/monitoring configs
